//
//  main.cpp
//  HelloVenus
//
//  Created by Michael Zuccarino on 6/14/15.
//  Copyright (c) 2015 TeamSuperKawaii. All rights reserved.
//

#include <iostream>
#include "Date.h"
#include "Contact.h"
#include "ContactDatabase.h"
#include "XMLInteractions.h"

int main(int argc, const char * argv[]) {
    // insert code here...
    
    
    DB oskarDB = DB();
    oskarDB.DEBUGCOTROLL();
    
    
    
    return 0;
}
